#!/opt/local/bin python

    #   SIMSEISTimeSeries.py    -   This code uses a Poisson distribution to generate state variable
    #       timeseries similar to those obtained by the various Nowcasting codes of Rundle et al.  
    #       The idea is to use a Poisson distribution, the common model used for seismicity interval statistics.
    #   
    #   Poisson distribution = 1 - exp(t/tau)
    #
    #   This code was written on a Mac using Macports python, but Anaconda python should work as well.
    
    #   ---------------------------------------------------------------------------------------
    
    # Copyright 2022 by John B Rundle, University of California, Davis, CA USA
    # 
    # Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated 
    # documentation files (the     "Software"), to deal in the Software without restriction, including without 
    # limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, 
    # and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
    # 
    # The above copyright notice and this permission notice shall be included in all copies or suSKLantial portions of the Software.
    # 
    # THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE 
    # WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR 
    # COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, 
    # ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

    #   ---------------------------------------------------------------------------------------
    
import sys
import os
import numpy as np
from array import array
from numpy import random

import math

import numpy as np
import scipy

import matplotlib.pyplot as plt

import SIMSEISCalcMethods
import SIMSEISPlotMethods

    #################################################################
    #################################################################
    
    #   PARAMETERS
    
    #   Elementary State Variable:     ESV = 1 - exp(t/Tau) 
    
    #   Three Primary Adjustable Parameters Are:
    #
    #       Tau:                Will be a random variable that determines the
    #                           between "large earthquakes"
    #   
    #       Threshold_SV:       Specifies the value of the state variable 
    #                           at which the "large earthquake" occurs. Can
    #                           be a random variable.
    #   
    #       Residual_SV:        Specifies the value of the state variable
    #                           when recovery begins (i.e., essentially the number
    #                           of aftershocks).  Can be a random variable.
    #
    #   Other Main Parameters:
    #
    #       TW, or forecast_interval:   In basic time units, which we assume
    #                           to be months
    #
    #   Total number of months:     NMonths
    
    #################################################################
    #################################################################
    
if __name__ == '__main__':

    #################################################################
    
    #  INPUTS
    
    Threshold_SV = 0.995    #   Failure threshold
    sigma_threshold = 0.0   #   Change this to a number between 0 and 1 if you want a random failure threshold
    
    Residual_SV = 0.0       #   At failure, time series defaults to 0 residual
    sigma_residual = 0.0    #   Change this to a number between 0 and 1 if you want a random residual
    
    Tau = 25.0     #   In "lunar months"

    
    TWindow = 13.0    #   3 year forecast time in "lunar months"
    
    number_thresholds = 50
    
    #################################################################
        
    #   Basic Time Series
    Plot_Sim_Timeseries             =   False       #   Basic time series
    Plot_Sim_Timeseries_Precision   =   False       #   Basic time series plus Positive Predictive Value (PPV)
    Plot_Sim_Timeseries_Accuracy    =   False       #   Basic time series plus Accuracy
    
    #   Interval Statistics
    Plot_Cumulative_Statistics      =   False       #   Plot interval statistics cumulatively
    Plot_Interval_Histogram         =   False       #   Plot interval statistics as histogram
    
    #   Receiver Operating Characteristic and Shannon Information
    Plot_ROC                        =   False       #   Plot Receiver Operating Characteristic
    Calc_KL_JS_Divergence           =   False       #   Plot the Kullback-Leibler and Jensen-Shannon Divergences from Information theory
                                                    #       (Refer to Wikipedia entries for explanations)
    
    NMonths = 25000    #   For the statistics
    
    recurrence_intervals, time_months, state_variable, activity, large_event_times = SIMSEISCalcMethods.calc_timeseries\
                (NMonths, Threshold_SV, sigma_threshold, Residual_SV, sigma_residual, Tau)
    
    if Plot_Sim_Timeseries:
    
        SIMSEISPlotMethods.plot_timeseries(time_months, state_variable, activity, large_event_times, Tau, TWindow)
        
    if Plot_Cumulative_Statistics:
    
        SIMSEISPlotMethods.plot_cumulative(recurrence_intervals, NMonths, Tau, TWindow)
        
    if Plot_Interval_Histogram:
    
        SIMSEISPlotMethods.plot_histogram(recurrence_intervals, NMonths, Tau, TWindow)
        
    if Plot_ROC:
    
        NMonths = 10000    #   For the statistics
        
        recurrence_intervals, time_months, state_variable, activity, large_event_times = SIMSEISCalcMethods.calc_timeseries\
                (NMonths, Threshold_SV, sigma_threshold, Residual_SV, sigma_residual, Tau)
        
        SIMSEISPlotMethods.plot_temporal_ROC(time_months, state_variable, large_event_times, TWindow, Threshold_SV, Tau)
        
    if Plot_Sim_Timeseries_Precision:
    
        NMonths = 10000    #   For the statistics
        
        recurrence_intervals, time_months, state_variable, activity, large_event_times = SIMSEISCalcMethods.calc_timeseries\
                (NMonths, Threshold_SV, sigma_threshold, Residual_SV, sigma_residual, Tau)
    
        SIMSEISPlotMethods.plot_timeseries_precision(time_months, state_variable, activity, large_event_times, Tau, TWindow, Threshold_SV)
        
    if Plot_Sim_Timeseries_Accuracy:
    
        NMonths = 10000    #   For the statistics
        
        recurrence_intervals, time_months, state_variable, activity, large_event_times = SIMSEISCalcMethods.calc_timeseries\
                (NMonths, Threshold_SV, sigma_threshold, Residual_SV, sigma_residual, Tau)
    
        SIMSEISPlotMethods.plot_timeseries_accuracy(time_months, state_variable, activity, large_event_times, Tau, TWindow, Threshold_SV)
        
    if Calc_KL_JS_Divergence:
        
        random_flag = False
        
        true_positive, false_positive, true_negative, false_negative, threshold_value = \
                    SIMSEISCalcMethods.compute_ROC(time_months, state_variable, large_event_times, \
                    number_thresholds, TWindow, Threshold_SV, random_flag)
                
        true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate = \
                    SIMSEISCalcMethods.compute_ROC_rates(\
                    true_positive, false_positive, true_negative, false_negative)
        
        js_divergence, kl_divergence = SIMSEISCalcMethods.jensen_shannon_divergence\
                    (true_positive_rate, false_positive_rate, false_negative_rate, true_negative_rate)
                    
        print('')
        print('-----------------------------------')
        print('')
        print('For TWindow: ' + str(TWindow) + ' Months:')
        print('')
        print('      Kullback-Leibler Divergence: ' + str(round(kl_divergence,3)) + ' Bits')
        print('        Jensen-Shannon Divergence: ' + str(round(js_divergence,3)) + ' Bits')
        print('')
        print('-----------------------------------')
        print('')
    
#         
    #################################################################
    

    
